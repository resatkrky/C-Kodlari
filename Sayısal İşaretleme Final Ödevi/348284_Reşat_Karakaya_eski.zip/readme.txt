Reşat Karakaya
348284
Kodun çalışması için girdi.wav ses dosyası aynı dizinde bulunmalı
Kod çalıştırıldığı zaman 2 seçenek sunar.
Birincisi direk kodda verilen FIR Filtreleriyle işlem yapar.
İkincisi FIR Filtresinin boyutunu sizden ister ve 
FIR Filtre degerlerini sizin girmenizi ister.
Program calisinca FIR Filtreleme yapilir ve cikti.wav, cikti.csv dosyaları oluşur.

