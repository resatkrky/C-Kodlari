Reşat Karakaya
348284
Kodun çalışması için girdi.wav ses dosyası aynı dizinde bulunmalı
girdi.wav ses dosyası FIR filtreleme işlemi yapılacak ses dosyasıdır.
Kod çalıştırıldığı zaman 2 seçenek sunar.
Birincisi direk kodda verilen FIR Filtreleri değerleriyle işlem yapar.
İkincisi FIR Filtresinin boyutunu sizden ister ve FIR Filtre degerlerini sizin girmenizi ister.
Program calisinca FIR Filtreleme yapilir ve cikti.wav, cikti.csv dosyaları oluşur.
cikti.wav FIR filtre uygulandıktan sonra elde edilen .wav dosyasıdır.
cikti.csv kod çalışırken ekstra olarak dft işlemi yapar. i_frek ve r_frek değerlerini verir.
