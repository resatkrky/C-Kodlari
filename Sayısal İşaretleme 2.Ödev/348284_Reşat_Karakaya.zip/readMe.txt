Reşat Karakaya
348284

Dosyayı zipten çıkardıktan sonra içerisinde girdi olarak bir .bmp dosyası bulunuyor.
Programı çalıştırdığınız zaman .bmp dosyasının histogramını, ortalamasını ve varyansını hesaplıyor.
Eğer verilenden farklı bir .bmp dosyası kullanılacaksa ismine dikkat edilmesi gerekiyor.
İsmine dikkat edilmezse istenilen sonuçlar elde edilmez.

